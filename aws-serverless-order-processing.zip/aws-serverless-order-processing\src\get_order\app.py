import json
import logging
import os
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class DecimalEncoder(json.JSONEncoder):
    def default(self, value):
        if isinstance(value, Decimal):
            return int(value) if value % 1 == 0 else float(value)
        return super().default(value)


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, cls=DecimalEncoder),
    }


def lambda_handler(event, context):
    order_id = (event.get("pathParameters") or {}).get("order_id")
    if not order_id:
        return response(400, {"message": "order_id is required"})

    table = boto3.resource("dynamodb").Table(os.environ["ORDERS_TABLE"])
    try:
        result = table.get_item(Key={"order_id": order_id}, ConsistentRead=True)
    except ClientError:
        logger.exception("Could not retrieve order")
        return response(500, {"message": "Could not retrieve order"})

    order = result.get("Item")
    if not order:
        return response(404, {"message": "Order not found"})
    return response(200, order)

