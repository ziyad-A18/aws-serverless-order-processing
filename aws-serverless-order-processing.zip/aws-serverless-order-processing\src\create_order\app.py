import base64
import json
import logging
import os
import uuid
from datetime import datetime, timezone
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def _resources():
    table = boto3.resource("dynamodb").Table(os.environ["ORDERS_TABLE"])
    queue = boto3.client("sqs")
    return table, queue


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }


def parse_body(event):
    raw = event.get("body")
    if not raw:
        raise ValueError("Request body is required")
    if event.get("isBase64Encoded"):
        raw = base64.b64decode(raw).decode("utf-8")
    try:
        body = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ValueError("Request body must be valid JSON") from exc
    if not isinstance(body, dict):
        raise ValueError("Request body must be a JSON object")
    return body


def validate_order(body):
    email = body.get("customer_email")
    items = body.get("items")
    if not isinstance(email, str) or "@" not in email or len(email) > 254:
        raise ValueError("customer_email must be a valid email address")
    if not isinstance(items, list) or not items:
        raise ValueError("items must be a non-empty array")

    normalized = []
    total = Decimal("0")
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise ValueError(f"items[{index}] must be an object")
        product_id = item.get("product_id")
        quantity = item.get("quantity")
        unit_price = item.get("unit_price")
        if not isinstance(product_id, str) or not product_id.strip():
            raise ValueError(f"items[{index}].product_id is required")
        if isinstance(quantity, bool) or not isinstance(quantity, int) or quantity < 1:
            raise ValueError(f"items[{index}].quantity must be a positive integer")
        try:
            price = Decimal(str(unit_price))
        except Exception as exc:
            raise ValueError(f"items[{index}].unit_price must be a number") from exc
        if not price.is_finite() or price < 0:
            raise ValueError(f"items[{index}].unit_price must be zero or greater")
        price = price.quantize(Decimal("0.01"))
        normalized.append({
            "product_id": product_id.strip(),
            "quantity": quantity,
            "unit_price": price,
        })
        total += price * quantity
    return email.lower(), normalized, total.quantize(Decimal("0.01"))


def lambda_handler(event, context):
    try:
        email, items, total = validate_order(parse_body(event))
    except ValueError as exc:
        return response(400, {"message": str(exc)})

    order_id = str(uuid.uuid4())
    created_at = datetime.now(timezone.utc).isoformat()
    order = {
        "order_id": order_id,
        "customer_email": email,
        "items": items,
        "total": total,
        "status": "PENDING",
        "created_at": created_at,
        "updated_at": created_at,
    }

    table, sqs = _resources()
    try:
        table.put_item(Item=order, ConditionExpression="attribute_not_exists(order_id)")
        sqs.send_message(
            QueueUrl=os.environ["ORDERS_QUEUE_URL"],
            MessageBody=json.dumps({"order_id": order_id}),
        )
    except ClientError:
        logger.exception("Could not create order")
        return response(500, {"message": "Could not create order"})

    logger.info("Order accepted", extra={"order_id": order_id})
    return response(202, {
        "order_id": order_id,
        "status": "PENDING",
        "total": str(total),
        "message": "Order accepted for asynchronous processing",
    })

